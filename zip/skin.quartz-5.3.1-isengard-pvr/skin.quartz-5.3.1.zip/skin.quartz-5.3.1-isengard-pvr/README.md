# quartz

Quartz skin for KODI

Visit following site for more information: http://forum.kodi.tv/showthread.php?tid=264544