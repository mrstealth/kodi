# quartz

Quartz skin for KODI - original project.

This project is no longer being maintained by me. 
Take a look at some of the forks for further developement.
